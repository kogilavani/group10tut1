//
//  ViewController.h
//  group10tut1
//
//  Created by Janga, Likitha (UMKC-Student) on 6/15/15.
//  Copyright (c) 2015 Janga, Likitha (UMKC-Student). All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

